#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

void wakeup(int sig) {
    printf("child %d continue\n", getpid());
}

int main() {
    while (1) {
        pid_t pid_ls = fork();
        if (pid_ls < 0) {
            perror("fork ls");
            exit(1);
        }

        if (pid_ls == 0) {
            signal(SIGUSR1, wakeup);
            pause();
            execlp("ls", "ls", "-l", NULL);
            perror("exec ls");
            exit(1);
        }

        pid_t pid_ps = fork();
        if (pid_ps < 0) {
            perror("fork ps");
            exit(1);
        }

        if (pid_ps == 0) {
            execlp("ps", "ps", NULL);
            perror("exec ps");
            exit(1);
        }

        waitpid(pid_ps, NULL, 0);
        kill(pid_ls, SIGUSR1);
        waitpid(pid_ls, NULL, 0);

        sleep(3);
    }

    return 0;
}


